import re

def scan_file_for_sensitive_data(file_content):
    # Example regex for detecting sensitive data like emails and phone numbers
    sensitive_info = []

    # Simple email pattern (can be expanded)
    email_pattern = r'[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}'
    sensitive_info.extend(re.findall(email_pattern, file_content))

    # Simple phone number pattern (can be expanded)
    phone_pattern = r'\(?\+?[0-9]*\)?[-.\s]?[0-9]+[-.\s]?[0-9]+[-.\s]?[0-9]+'
    sensitive_info.extend(re.findall(phone_pattern, file_content))

    return ', '.join(sensitive_info)  # Return a comma-separated string of sensitive info

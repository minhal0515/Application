This is a web-based application for scanning uploaded files to identify sensitive data using regular expressions. The app stores the scanned information in a database and provides features to view, delete, and manage scans.

FEATURES:

1)File upload and scanning for sensitive data.
2)Storage of scan results in a database.
3)View all scanned files and their details.
4)Delete specific scan records.

Diagram on lucid app of the system:

https://lucid.app/lucidchart/773f1fef-e482-45a3-836e-e16e759ae4bb/edit?invitationId=inv_890444c6-0b56-4e6a-bef2-c220d48d0af0

Database schema:

Table: scans
- id (Primary Key): Unique ID for the scan.
- filename (Text): Name of the uploaded file.
- sensitive_info (Text): Sensitive data found in the file.
- timestamp (DateTime): Date and time of the scan.

Setup Instructions:

1) Clone repository
git clone <your-local-repo-path>
cd <project-folder>

2) Set up virtual environment
python -m venv venv
source venv/bin/activate  # For Linux/Mac
venv\Scripts\activate  # For Windows

3) Install dependencies
pip install -r requirements.txt

4) Set up database
from application import db
db.create_all()

5) Run the application!
python application.py

6) Access the Application
Open your browser and go to: http://127.0.0.1:5000
